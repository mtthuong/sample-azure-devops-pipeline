<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lbl_Program</name>
   <tag></tag>
   <elementGuidId>ed12c1cf-7f76-4e6c-959a-7453fd4a3c45</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>program</value>
   </webElementProperties>
</WebElementEntity>
